<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Coba Upload</title>
</head>
<body>
	<?php 
	
	?>

	<form action="UploadForm.php" method = "POST" enctype="multipart/form-data">
		<label>Upload File:</label>
		<input type="file" name ="upload" id = "file"><br>
		<input type="submit" value="submit" name="submit"> 
	</form>

</body>
</html>